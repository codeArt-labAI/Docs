# SecAuditLog_To_Splunk — SAP Cloud Integration iFlow

Extracts the **S/4HANA Cloud Public Edition Security Audit Log** via the **OData V4**
adapter on a **15-minute delta cadence**, triggered by an **external scheduler over
HTTPS**, persists a last-run high-water mark, pages through **all** records, and
forwards them to **Splunk HEC** — with a concurrency lock, full pagination, and an
exception subprocess that never advances the high-water on failure (at-least-once).

Built to the spec in [`docs/BUILD_SPEC.md`](docs/BUILD_SPEC.md). This is a **complete**
iFlow, not a scaffold: all four spec placeholders are implemented (Data Store
Get/Write, Looping Process Call + Local Integration Process, Exception Subprocess,
real router conditions).

---

## What you actually have to change

For a first run you only need to point two URLs at your systems (see
[`src/main/resources/parameters.prop`](src/main/resources/parameters.prop)) and deploy
two pieces of security material. Everything else has working defaults.

| Change | Where | Value |
|---|---|---|
| **S/4HANA OData base URL** | `parameters.prop` → `odata.address` | `https://<tenant>-api.s4hana.cloud.sap/sap/opu/odata4/sap/rsau_log_api/srvd_a2x/sap/rsau_log_api/0001` |
| **Splunk HEC URL** | `parameters.prop` → `splunk.hec.address` | `https://<splunk-host>:8088/services/collector/event` |
| **HEC token** (secret) | Security Material → *Secure Parameter* | alias `splunk.hec.token` |
| **S/4 OAuth2 client creds** (secret) | Security Material → *OAuth2 Credentials* | alias `S4HC_SAL_OAUTH` |

> Secrets are **never** in `parameters.prop` or Git — they are deployed security
> material referenced by alias (`{{splunk.hec.token}}`, `S4HC_SAL_OAUTH`). See §14 of the spec.

---

## Deploy

1. **Import the project** into your Integration Suite tenant:
   `Design → <your package> → Add → Integration Flow → Import` and pick
   [`SecAuditLog_To_Splunk.zip`](../SecAuditLog_To_Splunk.zip) (or import this unzipped
   project via a Git-backed workspace / CTS+ / SAP Piper).
2. **Create security material** (`Monitor → Integrations → Security Material`):
   - *Secure Parameter* `splunk.hec.token` = your HEC token (value only, the flow
     prepends `Splunk `).
   - *OAuth2 Credentials* `S4HC_SAL_OAUTH` = the S/4HANA Cloud communication-arrangement
     client id/secret + token URL (comm scenario **SAP_COM_0750**).
3. **Configure** the iFlow (the *Configure* button) and set `odata.address` +
   `splunk.hec.address`. Confirm the OData channel opens as **V4** (not V2).
4. **Save → Deploy.** `Monitor → Manage Integration Content` should show *Started*.
5. Grab the runtime endpoint URL — it ends in `/extract/secauditlog`.

## Wire the external scheduler

Point your enterprise scheduler (BTP Job Scheduling Service / Control-M / Redwood) at:

```
POST https://<cpi-runtime-host>/http/extract/secauditlog
```

- **Cadence:** every 15 minutes. The 15-minute schedule lives in the scheduler, **not**
  in a CPI Timer (spec §3).
- **Auth:** the sender uses **role-based** auth with a dedicated role
  `Splunk_SecAudit_Trigger` (not the broad `ESBMessaging.send`). Create that role in the
  tenant and grant it to the scheduler's client credentials / certificate. CSRF is off
  for this POST.
- The body is ignored; an empty POST is fine.

## Data Store setup

The flow uses one Data Store `SEC_AUDIT_DELTA` (auto-created on first write) with entries:

| Entry | Purpose |
|---|---|
| `SecAuditLog_LastRun` | high-water mark (advanced only after all pages delivered) |
| `SecAuditLog_Lock`    | concurrency lock (set at run start, cleared at end and on error) |
| `SecAuditLog_LastError` | last error marker (written by the exception subprocess) |

---

## How it works (delta + pagination + safety)

- **Run window** (`initRunWindow.groovy`): `runStartTime = now (UTC, second precision)`
  captured **once**, used as both the query upper bound and the next high-water value.
- **Lower bound** (`resolveDelta.groovy`): the stored high-water, or `runStartTime − 15m`
  on the first run.
- **OData V4 query** (`buildODataQuery.groovy`):
  `$filter=<TS> gt <lo> and <TS> le <hi>&$orderby=<TS> asc&$top=<n>&$skip=<k>`
  with **unquoted** `Edm.DateTimeOffset` literals (V4, not V2 `datetime'...'`).
- **Pagination**: a **Looping Process Call** drives a **Local Integration Process** that
  builds the page query, calls OData, maps the page to HEC NDJSON, and POSTs it —
  **process-and-forward per page**, never buffering the whole delta.
  `pageAdvance.groovy` sets `hasMore` from `@odata.nextLink` (preferred) or
  `returnedCount == pageSize`, and increments `$skip`.
- **High-water advance**: only **after** the loop completes successfully.
- **Concurrency guard** (§11): a Data Store lock; an overlapping trigger replies 200 and
  skips.
- **Exception subprocess** (§12): stamps window bounds + page count into MPL custom
  headers, writes an error marker, **releases the lock**, and **does not** advance the
  high-water → next run re-pulls the window (at-least-once).
- **Idempotency** (§13): because the window uses strict `gt`, dedup in Splunk on a stable
  key (e.g. timestamp + user + terminal + message id) — confirm fields against `$metadata`.

## Groovy scripts (`src/main/resources/script/`)

| Script | Role |
|---|---|
| `initRunWindow.groovy` | capture `runStartTime`, seed paging + envelope metadata |
| `evalLock.groovy` | turn the lock Data-Store-Get result into `lockHeld` |
| `resolveDelta.groovy` | lower bound + `firstRun` flag (bootstrap when empty) |
| `buildODataQuery.groovy` | assemble the V4 query for the current page |
| `pageAdvance.groovy` | `hasMore` / `returnedCount` / advance `$skip` |
| `toHecNdjson.groovy` | OData page → HEC NDJSON (one envelope per record; empty-safe) |
| `handleError.groovy` | exception subprocess: MPL headers + alert payload |

---

## ⚠️ First-open verification (spec §21 — hand-authored `.iflw` is version-sensitive)

The XML is well-formed and every reference resolves, but a few step *component versions*
in a hand-authored flow can differ from your tenant's installed versions. On first open
the Web editor may prompt **"a newer version of this component is available"** — **accept**
the upgrade, then re-verify these specific spots:

1. **Looping Process Call** (`ProcessCall_Loop`) — confirm it is a *Looping* Process Call,
   that it points at the **`Paginate` local integration process**, and that the loop
   condition is `${property.hasMore} = 'true'` with a max-iteration cap (10000) set to
   throw on limit.
2. **Data Store steps** (Get/Write/Delete) — confirm each shows the right operation and the
   store name `SEC_AUDIT_DELTA` / correct entry ids. Set *Get* → "Throw Exception on Missing
   Entry = false".
3. **Exception Subprocess** — confirm the *Error Start* event is recognized and the
   subprocess is wired (Handle Error → Write Error Marker → Release Lock → End).
4. **OData channel** — confirm it opens as **OData V4** (Message Protocol), operation
   `Query(GET)`, resource path `SecurityAuditLog`, Query Options `${property.odataQuery}`.
5. **Splunk HTTP channel** — POST, and the `Authorization` + `Content-Type` request headers
   are allowed through (they are set by the *Set HEC Auth Headers* Content Modifier).

None of these change the design — they are editor re-confirmations after a hand-generated
import, exactly as the spec anticipates.

## Acceptance checklist (spec §20)

- [ ] Second invocation with no new events → **no** Splunk writes, high-water unchanged.
- [ ] A run > `pageSize` records pages through **all** of them.
- [ ] Simulated HEC failure mid-run leaves high-water **unchanged**; next run re-pulls.
- [ ] Overlapping trigger while a run is in progress is **skipped** (lock).
- [ ] Timestamps compared are UTC; unquoted V4 literals; `$orderby` present.
- [ ] No secrets committed.

## Reuse for the other three log types

Clone and change only `odata.entitySet`, `odata.tsField`, `splunk.sourcetype`, and the
Data Store entry ids (`highwater.entryId` / `lock.entryId` / `error.entryId`). The
delta / pagination / HEC machinery is identical (SAP_COM_0894 RAL, SAP_COM_0933 user
change, SAP_COM_0934 role change).
