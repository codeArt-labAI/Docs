# Build Spec — S/4HANA Cloud Security Audit Log → Splunk HEC (SAP CPI iFlow)

**Audience:** Claude Code (implementation agent)
**Artifact type:** SAP Cloud Integration (Integration Suite) integration flow + supporting Groovy, config, and CI/CD.
**Goal:** Produce a deployable iFlow that extracts the S/4HANA Cloud Public Edition **Security Audit Log** via the **OData V4** adapter on a **15-minute delta cadence**, triggered by an **external scheduler over HTTPS**, persisting a last-run high-water mark, paginating through all records, and forwarding to **Splunk HEC**.

> This is one of four S/4HANA Cloud security log types feeding a Splunk SIEM. Keep the design generic enough that the same pattern can be cloned for the other three log types by changing the OData entity set, field names, and sourcetype.

---

## 1. Objective

Deliver a production-ready iFlow project that:

1. Is triggered by an external scheduler (not a CPI Timer) via an HTTPS sender endpoint every 15 minutes.
2. Reads a persisted last-run timestamp (high-water mark).
3. Builds a bounded delta OData V4 query and pages through **all** matching Security Audit Log records.
4. Transforms each page into Splunk HEC events and POSTs them to the HEC endpoint.
5. Advances the high-water mark **only** after all pages are delivered successfully.
6. Handles errors without losing data (at-least-once), prevents overlapping runs, and is observable.

---

## 2. Context & assumptions

- **Source:** S/4HANA Cloud Public Edition, Security Audit Log exposed as an **OData V4** service (entity set + timestamp field to be confirmed from the service EDMX/`$metadata`).
- **Target:** Splunk **HTTP Event Collector (HEC)**, `POST /services/collector/event`, token auth.
- **Trigger:** External enterprise scheduler (BTP Job Scheduling Service / Control-M / Redwood) calling the HTTPS endpoint every 15 min. The iFlow itself is stateless per invocation; the delta window provides continuity.
- **Runtime:** SAP Integration Suite, Cloud Integration (standard cloud runtime assumed; call out any Edge Integration Cell differences).

---

## 3. Trigger model (important)

The requirement "15-minute schedule" **and** "externally triggered via HTTP" is reconciled as: an **external scheduler POSTs to an HTTPS sender endpoint every 15 minutes.** Do **not** use a CPI Timer start event. The sender is an HTTPS sender adapter; the 15-minute cadence lives in the external scheduler.

---

## 4. High-level flow

```
External Scheduler --HTTPS POST /extract/secauditlog (every 15 min)-->
  [Concurrency guard: lock free?]
    -> Init (capture runStartTime UTC; page params)
    -> Data Store GET last high-water
    -> Router: first run? (bootstrap lower bound if empty)
    -> Build OData V4 delta query
    -> Looping Process Call --> Local Integration Process (per page):
           OData V4 Request-Reply (Query GET, $top/$skip)
           -> Map page to Splunk HEC (NDJSON)
           -> HTTPS Receiver -> Splunk HEC
           -> loop while more pages
    -> Data Store WRITE high-water = runStartTime
    -> Release lock
    -> Reply 200
  [Exception Subprocess: alert; DO NOT advance high-water; release lock]
```

---

## 5. Detailed step design — main Integration Process

| # | Step | Type | Key config |
|---|------|------|-----------|
| 1 | HTTPS Sender | Sender adapter | Address `/extract/secauditlog`; auth = client cert **or** OAuth2 client-credentials mapped to a **custom role** (not broad `ESBMessaging.send`); CSRF off for the scheduler POST. |
| 2 | Concurrency guard | Data Store / gateway | Check a lock entry; if a run is in progress, reply 200 and skip. See §11. |
| 3 | Init | Content Modifier | Set property `runStartTime` (UTC ISO-8601), `pageSize` (e.g. 1000), `pageSkip=0`. See §9. |
| 4 | Read high-water | Data Store **Get** | Store `SEC_AUDIT_DELTA`, entry `SecAuditLog_LastRun`. |
| 5 | First run? | Router (exclusive gateway) | If high-water empty → bootstrap lower bound (`runStartTime − 15m`). Default branch = normal delta. |
| 6 | Build query | Content Modifier | Assemble `$filter/$orderby/$select`. See §8. |
| 7 | Looping Process Call | Looping Process Call | Loop while more pages; **max-iteration cap** with "throw on limit". Calls the Local Integration Process (§6). |
| 8 | Write high-water | Data Store **Write** | `SecAuditLog_LastRun = runStartTime`, high retention. Only reached after the loop completes. |
| 9 | Release lock + Reply 200 | Data Store Delete + end | Clear lock; return 200 to scheduler. |

---

## 6. Local Integration Process (pagination) — invoked per page

1. **OData V4 Request-Reply** — operation `Query(GET)`, entity set = Security Audit Log set; query options = delta `$filter` + `$orderby` + `$select` + `$top=${pageSize}&$skip=${pageSkip}`.
2. **Map to Splunk HEC** — build newline-delimited JSON (NDJSON), one HEC envelope per record. See §10.
3. **HTTPS Receiver → Splunk HEC**.
4. **Advance page / loop control** — on HEC 2xx: `pageSkip += pageSize`; set `hasMore` from `@odata.nextLink` presence (preferred) or `returnedCount == pageSize`. On HEC failure: throw (so high-water is not advanced) or route to a JMS retry queue.

**Pagination guidance:** prefer **explicit `$top`/`$skip`** driven by the Looping Process Call and **process-and-forward each page** (never buffer the whole delta in memory) — a security-log delta can burst and letting the V4 adapter auto-follow the entire `@odata.nextLink` chain risks MPL memory limits. If the backend is slow on deep `$skip`, switch to chaining the server `$skiptoken` from `@odata.nextLink` instead.

---

## 7. Delta / high-water logic (exact rules)

- Capture `runStartTime = now (UTC)` **once, at the very start** of the run. This is both the query **upper bound** and the **next** high-water value.
- Query window: `TS > lastHighWater AND TS <= runStartTime`. Bounding the upper end avoids a race with events arriving mid-run.
- **Advance the high-water to `runStartTime` only after every page is delivered.** On any failure, leave the previous value so the next run re-pulls the window (at-least-once).
- First run (empty high-water): bootstrap lower bound to `runStartTime − 15m` (or a configured initial datetime).

---

## 8. OData V4 query construction (exact literal syntax)

- `$filter=<TSField> gt <lastHighWater> and <TSField> le <runStartTime>`
- `$orderby=<TSField> asc`  ← **mandatory** for stable paging.
- `$select=<minimal field list>`.
- **V4 gotcha:** `Edm.DateTimeOffset` literals are **unquoted** ISO-8601, e.g. `... gt 2026-08-04T09:15:00Z`. Do **not** use the OData **V2** form `datetime'...'`.
- `<TSField>` = the real audit-timestamp property from the service `$metadata`; confirm it is emitted in **UTC**.

---

## 9. Timestamp / UTC handling

Set `runStartTime` in the Init Content Modifier (Exchange Property, Type = Expression):

```
${date-with-timezone:now:UTC:yyyy-MM-dd'T'HH:mm:ss'Z'}
```

- Use `date-with-timezone:...:UTC:...` so the value is **converted** to UTC before formatting.
- The common `${date:now:...'Z'}` form also works **only** because standard cloud CPI worker nodes run in UTC — the `'Z'` is a quoted literal that does no timezone conversion, and `date:now` formats in the node's default TZ. It is therefore correct on standard cloud runtime but **not** guaranteed on Edge Integration Cell / self-managed runtimes where the node TZ may differ. Prefer the explicit `date-with-timezone` form for a high-water boundary.
- **Precision:** the second-precision pattern truncates sub-second events. If the audit timestamp carries fractional seconds and you filter with `le runStartTime`, either match the field precision (`...ss.SSS'Z'`) or rely on Splunk-side dedup (§13).
- Bootstrap expression: `${date-with-timezone:now-15m:UTC:yyyy-MM-dd'T'HH:mm:ss'Z'}`.
- Strict-precision Groovy alternative: `Instant.now().truncatedTo(ChronoUnit.SECONDS).toString()`.

---

## 10. Splunk HEC delivery

- Receiver: HTTPS to `https://<splunk-host>:8088/services/collector/event`, `POST`.
- Header `Authorization: Splunk <HEC-token>` sourced from a **Secure Parameter** / deployed credential (never inline).
- Payload: newline-delimited JSON, one envelope per record:

```json
{"time": <epoch or ISO>, "host": "<s4-system>", "source": "s4hana", "sourcetype": "sap:securityauditlog", "event": { ...audit record fields... }}
```

- **Batch** multiple events per HEC call (NDJSON) for throughput; respect HEC per-request payload size limits (compress / cap batch size if large).
- Enable **indexer acknowledgement** if guaranteed delivery is required.

---

## 11. Concurrency guard

An external 15-minute trigger can overlap a long backfill run. Prevent two runs advancing the same window:

- Set a Data Store **lock** entry at run start; clear it at successful end and in the Exception Subprocess.
- If the lock exists at start, reply 200 and skip the run.
- Alternatively pin the iFlow to single concurrency. Prefer the explicit lock for visibility.

---

## 12. Error handling / Exception Subprocess

- Add an Exception Subprocess that: raises an **alert** (mail/Slack), **does not** write/advance the high-water, writes an **error marker**, and **releases the lock**.
- Stamp window bounds (`lastHighWater`, `runStartTime`) and page count into **MPL custom headers** for audit traceability.
- Consider a JMS intermediate queue between extraction and Splunk delivery for retry + backpressure decoupling (optional enhancement; consistent with the retry pattern used elsewhere).

---

## 13. Idempotency & boundary rules

- Because the window uses strict `gt lastHighWater`, events with a timestamp exactly equal to a page boundary can be dropped if split across pages. Mitigate by **dedup in Splunk on a unique event key**, or overlap the lower bound slightly and dedup.
- Define the unique key from stable audit fields (e.g. timestamp + user + terminal + message id) — confirm against `$metadata`.

---

## 14. Security

- Sender: client certificate or OAuth2 client-credentials; restrict to a dedicated custom role.
- Splunk token and any OAuth client secret held as Secure Parameters / deployed credentials, referenced by alias — never in the flow body or committed to Git.
- No secrets in `parameters.prop`.

---

## 15. Externalized parameters (`parameters.prop`)

```
odata.address        = https://<host>/sap/opu/odata4/<service>
odata.entitySet      = <EntitySet>
odata.tsField        = <TimestampProperty>
odata.pageSize       = 1000
splunk.hec.address   = https://<splunk-host>:8088/services/collector/event
splunk.sourcetype    = sap:securityauditlog
datastore.name       = SEC_AUDIT_DELTA
highwater.entryId    = SecAuditLog_LastRun
```

Credentials (HEC token, OAuth secret) are **deployed security material**, referenced by alias — not parameters.

---

## 16. Repo / project structure (CPI iFlow project)

```
SecAuditLog_To_Splunk/
  META-INF/MANIFEST.MF                 # SAP-BundleType: IntegrationFlow, symbolic name, version
  .project                             # ifl project natures
  metainfo.prop
  src/main/resources/
    scenarioflows/integrationflow/SecAuditLog_To_Splunk.iflw   # BPMN2 + ifl: extensions
    parameters.prop
    parameters.propdef
    script/                            # Groovy scripts (§19)
    mapping/                           # message mapping / MMap if used
  docs/                                # diagrams (mermaid + svg), this spec
```

Commit the **unzipped** project tree (not a `.zip`) so CI/CD (Piper / CTS+ / Git-backed design) can consume it.

---

## 17. Current scaffold (starting point)

A well-formed `.iflw` scaffold already exists and imports/opens with full DI. It contains:

- Sender participant (**Scheduler**) → HTTPS message flow into the start event (`urlPath=/extract/secauditlog`, role-based auth placeholder).
- Two receiver participants: **S4_SecurityAuditLog** (OData V4 message flow off the Request-Reply, `Query(GET)`, stub `$filter/$orderby/$top/$skip`) and **Splunk_HEC** (HTTP message flow, `POST /services/collector/event`).
- Linear step sequence with correct types: Start → Init (Content Modifier) → Read high-water → Router (First run?) → Build query → OData V4 Request-Reply → Map to HEC → Send to Splunk → Write high-water → End. Full BPMN DI included.
- Externalized params as in §15.

**Placeholders to replace (deliberately left out to guarantee clean import):**

1. The two Content Modifiers named `[Data Store Get]` / `[Data Store Write]` → real Data Store **Get** / **Write** steps.
2. Pagination loop → wrap OData + Map + Send in a **Looping Process Call** + **Local Integration Process** (§6).
3. **Exception Subprocess** (§12).
4. Router condition (currently stubbed `${property.firstRun} = 'X'`) → set `firstRun` from the Data Store Get result.

---

## 18. Deliverables for Claude Code

1. Complete `SecAuditLog_To_Splunk.iflw` with the four placeholders above implemented (Data Store Get/Write, Looping Process Call + Local Integration Process, Exception Subprocess, real router condition).
2. Groovy scripts per §19 under `src/main/resources/script/`.
3. Finalised `parameters.prop` / `parameters.propdef` and `MANIFEST.MF`.
4. `docs/` with the flow diagram(s).
5. Optional: CI/CD pipeline config (SAP Piper) for deploy to the tenant.
6. A short `README.md` describing deploy + the scheduler wiring (endpoint, cadence, auth role).

---

## 19. Groovy scripts to implement (contracts)

**a. `initRunWindow.groovy`** — set the run window and paging state.
- Input: exchange.
- Output properties: `runStartTime` (UTC ISO-8601, second precision), `pageSize`, `pageSkip=0`.
- Contract: `runStartTime` must be captured once and reused as both upper bound and next high-water.

**b. `resolveDelta.groovy`** — determine the lower bound.
- Input: Data Store Get result (may be empty), `runStartTime`.
- Output: `lastHighWater` (empty → bootstrap `runStartTime − 15m`), `firstRun` flag.

**c. `buildODataQuery.groovy`** (or Content Modifier) — assemble query options.
- Output header/property with `$filter=<TS> gt <lastHighWater> and <TS> le <runStartTime>&$orderby=<TS> asc&$select=...&$top=<pageSize>&$skip=<pageSkip>`.
- Enforce **unquoted** `Edm.DateTimeOffset` literals.

**d. `toHecNdjson.groovy`** — transform an OData page to Splunk HEC NDJSON.
- Input: OData V4 JSON page (`value[]`).
- Output: NDJSON body, one `{"time","host","source","sourcetype","event"}` per record; `time` derived from the audit timestamp (epoch seconds).
- Must handle empty page (no-op).

**e. `pageAdvance.groovy`** — loop control.
- Input: last OData response.
- Output: `hasMore` (from `@odata.nextLink` or `count == pageSize`), incremented `pageSkip`.

Skeleton for (d):

```groovy
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant

Message processData(Message message) {
    def body = message.getBody(String) ?: '{"value":[]}'
    def page = new JsonSlurper().parseText(body)
    def host = message.getProperty("s4System") ?: "s4hana"
    def sourcetype = message.getProperty("splunkSourcetype") ?: "sap:securityauditlog"
    def tsField = message.getProperty("tsField") ?: "TimeStamp"
    def sb = new StringBuilder()
    (page.value ?: []).each { rec ->
        def epoch = Instant.parse((rec[tsField] as String)).epochSecond
        def env = [time: epoch, host: host, source: "s4hana", sourcetype: sourcetype, event: rec]
        sb.append(JsonOutput.toJson(env)).append("\n")
    }
    message.setBody(sb.toString())
    return message
}
```

---

## 20. Acceptance criteria / test checklist

- [ ] Second invocation with no new events makes **no** Splunk writes and leaves the high-water unchanged.
- [ ] A run spanning > `pageSize` records pages through **all** of them (verify count vs source).
- [ ] Simulated HEC failure mid-run leaves the high-water **unchanged**; next run re-pulls the window.
- [ ] Overlapping trigger while a run is in progress is **skipped** (lock works).
- [ ] Timestamps compared are UTC; no drift on the delta boundary.
- [ ] No duplicates in Splunk after a re-pull (dedup key works), or duplicates are acceptable-by-design and documented.
- [ ] `$filter` uses unquoted V4 datetime literals; `$orderby` present.
- [ ] No secrets in the committed project.

---

## 21. Known fragilities / gotchas for the implementer

- **Hand-authored `.iflw` is version-sensitive.** `activityType` / `cmdVariantUri` strings for Data Store operations, Looping Process Call, and the error-event subprocess are easy to get subtly wrong and can make the flow fail to open. **Recommended:** export a known-good iFlow from the **target tenant** that already contains these step types and copy the exact `cmdVariantUri` / `componentVersion` values from it; validate every `.iflw` for XML well-formedness after generation.
- Verify the OData message flow opens as **V4** (not V2) after import; adjust the adapter message protocol if needed.
- Confirm the audit-log `$metadata`: exact entity set, timestamp property name, its precision and timezone, and a stable unique key for dedup.
- Expect the Web UI to prompt for a component version update on first open of a hand-generated flow — accept and re-verify the OData/HTTP adapter config.

---

*Reusability note:* to clone for the other three S/4HANA Cloud security log types, parameterise `odata.entitySet`, `odata.tsField`, `splunk.sourcetype`, and the Data Store entry id — the delta/pagination/HEC machinery is identical.
