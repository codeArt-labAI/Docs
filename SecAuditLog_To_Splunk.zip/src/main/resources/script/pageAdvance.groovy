/*
 * pageAdvance.groovy  (§19e, §6)
 * ---------------------------------------------------------------------------
 * Loop control. Runs on the raw OData V4 response (BEFORE the HEC mapping so
 * the @odata.nextLink / count is still available).
 *
 * Input:
 *   - message body = OData V4 JSON page: { "value":[...], "@odata.nextLink": "..." }
 *   - property pageSize, pageSkip
 *
 * Output properties:
 *   returnedCount = records in this page
 *   hasRecords    = 'X' when returnedCount > 0 (router: send vs skip)
 *   hasMore       = 'true'/'false' — drives the Looping Process Call condition
 *   pageSkip      = incremented by pageSize for the next iteration
 *
 * hasMore rule: prefer presence of @odata.nextLink; else returnedCount == pageSize.
 * The body (OData page) is left untouched for the downstream HEC mapper.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {

    String raw = message.getBody(String) ?: '{"value":[]}'
    def page
    try {
        page = new JsonSlurper().parseText(raw)
    } catch (Exception e) {
        page = [value: []]
    }

    int pageSize = (message.getProperty("pageSize") ?: 1000) as Integer
    int pageSkip = (message.getProperty("pageSkip") ?: 0) as Integer

    def rows = (page instanceof Map && page.value instanceof List) ? page.value : []
    int returnedCount = rows.size()

    boolean nextLink = (page instanceof Map) && (page["@odata.nextLink"] != null) &&
                       ((page["@odata.nextLink"] as String).trim().length() > 0)
    boolean hasMore = nextLink || (returnedCount == pageSize && returnedCount > 0)

    message.setProperty("returnedCount", returnedCount)
    message.setProperty("hasRecords", returnedCount > 0 ? "X" : "")
    message.setProperty("hasMore", hasMore ? "true" : "false")
    message.setProperty("pageSkip", pageSkip + pageSize)

    // Keep the OData body for the mapper.
    return message
}
