/*
 * initRunWindow.groovy  (§19a)
 * ---------------------------------------------------------------------------
 * Set the run window and paging state for one extraction run.
 *
 * Contract:
 *   - runStartTime is captured ONCE here (UTC, second precision) and is reused
 *     as BOTH the query upper bound AND the next high-water value.
 *   - Seeds paging state: pageSize, pageSkip=0, hasMore=true.
 *   - Seeds envelope metadata used by the HEC mapper.
 *
 * Output exchange properties:
 *   runStartTime, pageSize, pageSkip, hasMore, s4System, splunkSourcetype, tsField
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant
import java.time.temporal.ChronoUnit

Message processData(Message message) {

    // --- Capture the run start (UTC, truncated to whole seconds) -----------
    // Strict-precision, timezone-safe: Instant is always UTC.
    String runStartTime = Instant.now().truncatedTo(ChronoUnit.SECONDS).toString()  // e.g. 2026-08-06T09:15:00Z
    message.setProperty("runStartTime", runStartTime)

    // --- Paging state ------------------------------------------------------
    // pageSize comes from the externalized parameter {{odata.pageSize}} which is
    // injected as a header/property by the platform; fall back to 1000.
    def pageSizeProp = message.getProperty("pageSize")
    int pageSize = (pageSizeProp != null && (pageSizeProp as String).isInteger()) ? (pageSizeProp as String).toInteger() : 1000
    message.setProperty("pageSize", pageSize)
    message.setProperty("pageSkip", 0)
    message.setProperty("hasMore", "true")     // enter the loop at least once

    // --- Envelope metadata (defaults; overridden by externalized params) ---
    if (message.getProperty("s4System") == null)        message.setProperty("s4System", "s4hana-cloud")
    if (message.getProperty("splunkSourcetype") == null) message.setProperty("splunkSourcetype", "sap:s4hana:cloud:audit")
    if (message.getProperty("tsField") == null)          message.setProperty("tsField", "LogTimestamp")
    if (message.getProperty("bootstrapMinutes") == null) message.setProperty("bootstrapMinutes", "15")

    // Reset body so a stray inbound payload from the scheduler does not leak downstream.
    message.setBody("")
    return message
}
