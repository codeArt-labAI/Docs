/*
 * evalLock.groovy  (§11 concurrency guard)
 * ---------------------------------------------------------------------------
 * Runs immediately after the Data Store *Get* on the lock entry.
 *
 * The Data Store Get is configured with "Throw Exception on Missing Entry = false",
 * so when no lock is present the body is empty. If a previous run is still in
 * progress the lock entry holds its runStartTime, so the body is non-empty.
 *
 * Output property:
 *   lockHeld = 'X'  -> a run is already in progress (router will skip this run)
 *   lockHeld = ''   -> free to proceed
 *
 * The body is cleared afterwards so the lock payload does not pollute the flow.
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def body = message.getBody(String)
    boolean held = (body != null && body.trim().length() > 0)
    message.setProperty("lockHeld", held ? "X" : "")
    message.setBody("")
    return message
}
