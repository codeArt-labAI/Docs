/*
 * toHecNdjson.groovy  (§19d, §10)
 * ---------------------------------------------------------------------------
 * Transform one OData V4 page into Splunk HEC newline-delimited JSON (NDJSON),
 * one { "time","host","source","sourcetype","event" } envelope per record.
 *
 * Input:
 *   - message body = OData V4 JSON page ({ "value":[...] })
 *   - properties: s4System, splunkSourcetype, tsField
 *
 * Output:
 *   - message body = NDJSON (may be empty on an empty page -> no-op, the router
 *     upstream already skips the Splunk POST when hasRecords != 'X').
 *   - "time" derived from the audit timestamp (epoch seconds); if the field is
 *     missing/unparseable it is omitted so Splunk stamps receipt time.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant

Message processData(Message message) {

    def body       = message.getBody(String) ?: '{"value":[]}'
    def page       = new JsonSlurper().parseText(body)
    def host       = (message.getProperty("s4System")        ?: "s4hana-cloud") as String
    def sourcetype = (message.getProperty("splunkSourcetype") ?: "sap:s4hana:cloud:audit") as String
    def source     = (message.getProperty("splunkSource")    ?: "sap:cpi:secauditlog") as String
    def tsField    = (message.getProperty("tsField")         ?: "LogTimestamp") as String

    def sb = new StringBuilder()
    (page.value ?: []).each { rec ->
        def env = [host: host, source: source, sourcetype: sourcetype, event: rec]
        // Derive epoch seconds from the audit timestamp when present & parseable.
        def tsVal = rec[tsField]
        if (tsVal != null) {
            try { env.time = Instant.parse(tsVal as String).epochSecond } catch (Exception ignored) {}
        }
        sb.append(JsonOutput.toJson(env)).append("\n")
    }

    message.setBody(sb.toString())
    message.setHeader("Content-Type", "application/json")
    return message
}
