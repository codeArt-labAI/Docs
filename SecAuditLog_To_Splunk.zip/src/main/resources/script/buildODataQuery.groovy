/*
 * buildODataQuery.groovy  (§19c, §8)
 * ---------------------------------------------------------------------------
 * Assemble the OData V4 query options for the CURRENT page.
 *
 * Runs at the top of the pagination loop so $skip reflects the current page.
 *
 * Output:
 *   property  odataQuery  = the full "$filter=...&$orderby=...&$select=...&$top=..&$skip=.."
 *   header    odataQuery  = same value (the OData V4 receiver adapter reads
 *                           its Query Options field as ${property.odataQuery})
 *
 * Exact V4 syntax rules enforced:
 *   - Edm.DateTimeOffset literals are UNQUOTED ISO-8601 (NO datetime'...').
 *   - $orderby <TS> asc is mandatory for stable paging.
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    String ts     = (message.getProperty("tsField")      ?: "LogTimestamp") as String
    String lo     = message.getProperty("lastHighWater") as String
    String hi     = message.getProperty("runStartTime")  as String
    int    top    = (message.getProperty("pageSize")     ?: 1000) as Integer
    int    skip   = (message.getProperty("pageSkip")     ?: 0) as Integer
    String select = (message.getProperty("odataSelect")  ?: "") as String   // optional minimal field list

    StringBuilder q = new StringBuilder()
    // Unquoted V4 datetime literals:  <TS> gt 2026-08-06T09:00:00Z and <TS> le 2026-08-06T09:15:00Z
    q.append('$filter=').append(ts).append(' gt ').append(lo)
     .append(' and ').append(ts).append(' le ').append(hi)
    q.append('&$orderby=').append(ts).append(' asc')
    if (select?.trim()) q.append('&$select=').append(select.trim())
    q.append('&$top=').append(top)
    q.append('&$skip=').append(skip)

    String query = q.toString()
    message.setProperty("odataQuery", query)
    message.setHeader("odataQuery", query)
    return message
}
