/*
 * handleError.groovy  (§12 Exception Subprocess)
 * ---------------------------------------------------------------------------
 * Runs first in the Exception Subprocess.
 *
 * Responsibilities:
 *   - Stamp window bounds + page count into MPL custom headers for audit
 *     traceability (SAP_MessageProcessingLogCustomStatus + custom headers).
 *   - Build a compact alert payload (for the downstream mail/Slack receiver —
 *     wired with dummy values in this template).
 *   - It DOES NOT advance the high-water. The main-flow high-water Write is only
 *     reached on the success path, so leaving it untouched here yields at-least-once.
 *
 * The lock is released by a Data Store *Delete* step later in the subprocess.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

Message processData(Message message) {

    def ex = message.getProperty("CamelExceptionCaught")
    String errMsg = ex != null ? (ex.getMessage() ?: ex.toString()) : "Unknown error"

    String lastHighWater = message.getProperty("lastHighWater") as String
    String runStartTime  = message.getProperty("runStartTime")  as String
    def    pageSkip      = message.getProperty("pageSkip")

    // --- MPL custom headers for traceability -------------------------------
    message.setHeader("SAP_Audit_lastHighWater", lastHighWater)
    message.setHeader("SAP_Audit_runStartTime",  runStartTime)
    message.setHeader("SAP_Audit_pageSkip",      pageSkip as String)
    message.setHeader("SAP_MessageProcessingLogCustomStatus", "SECAUDIT_FAILED")

    // --- Alert payload (dummy target; wire a Mail/Slack receiver as needed) -
    def alert = [
        iflow        : "SecAuditLog_To_Splunk",
        status       : "FAILED",
        error        : errMsg,
        window_from  : lastHighWater,
        window_to    : runStartTime,
        pageSkip     : pageSkip,
        note         : "High-water NOT advanced; next run re-pulls this window."
    ]
    message.setProperty("errorMarker", JsonOutput.toJson(alert))
    message.setBody(JsonOutput.toJson(alert))
    return message
}
