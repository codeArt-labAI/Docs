/*
 * resolveDelta.groovy  (§19b, §7)
 * ---------------------------------------------------------------------------
 * Determine the lower bound of the delta window.
 *
 * Input:
 *   - message body  = result of the Data Store *Get* on the high-water entry
 *                     (empty on first run / after a reset).
 *   - property runStartTime  = upper bound captured in initRunWindow.
 *   - property bootstrapMinutes = look-back for the very first run.
 *
 * Output properties:
 *   lastHighWater = <stored value> OR (runStartTime - bootstrapMinutes) on first run
 *   firstRun      = 'X' when the store was empty, else ''
 *
 * Notes:
 *   - Edm.DateTimeOffset literals are UTC ISO-8601, second precision.
 *   - The stored high-water may be wrapped in whitespace/newlines by the store;
 *     it is trimmed here.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant
import java.time.temporal.ChronoUnit

Message processData(Message message) {

    String runStartTime = message.getProperty("runStartTime")
    String stored = message.getBody(String)
    stored = (stored == null) ? "" : stored.trim()

    if (stored.isEmpty()) {
        // ---- First run: bootstrap the lower bound -------------------------
        int mins = 15
        try { mins = Integer.parseInt(message.getProperty("bootstrapMinutes") as String) } catch (ignored) {}
        String lower = Instant.parse(runStartTime)
                              .minus(mins, ChronoUnit.MINUTES)
                              .truncatedTo(ChronoUnit.SECONDS)
                              .toString()
        message.setProperty("lastHighWater", lower)
        message.setProperty("firstRun", "X")
    } else {
        message.setProperty("lastHighWater", stored)
        message.setProperty("firstRun", "")
    }

    // Clear body; the OData query is built purely from properties.
    message.setBody("")
    return message
}
