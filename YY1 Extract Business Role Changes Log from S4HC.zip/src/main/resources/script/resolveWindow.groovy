/*
 * resolveWindow.groovy — YY1
 * ---------------------------------------------------------------------------
 * Runs right after the Data Store "Get" on entry LastRun. Decides the delta
 * window [windowFrom, runStartTime] and handles the two edge cases :
 *
 *  1) FIRST RUN (no stored LastRun): the Data Store Get returns an empty /
 *     non-timestamp body. We bootstrap windowFrom = now - defaultLookbackMinutes
 *     (default 15m) so the very first run pulls a small, safe window instead of
 *     everything.
 *
 *  2) LONG GAP / OUT-OF-MEMORY GUARD (e.g. the iFlow didn't run for 5 hours):
 *     we must resume from the last run time, but pulling 5h in one reply would
 *     blow MPL memory. So we CAP the span: windowTo = min(now, windowFrom +
 *     maxWindowMinutes) (default 60m). Only up to maxWindow of data is pulled &
 *     buffered per invocation; the new high-water is advanced to windowTo, and
 *     the response carries X-Caught-Up=false so the caller re-invokes immediately.
 *     A 5h backlog is therefore drained in ~5 bounded calls, never one giant one.
 *
 * Output properties:
 *   windowFrom, runStartTime (= capped windowTo & the next high-water),
 *   firstRun, caughtUp, truncated, acc(''), totalCount(0), + envelope metadata.
 *
 * Tunables (override by setting these exchange properties upstream, else defaults):
 *   defaultLookbackMinutes (15), maxWindowMinutes (60)
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant
import java.time.Duration
import java.time.temporal.ChronoUnit

Message processData(Message message) {

    Instant now = Instant.now().truncatedTo(ChronoUnit.SECONDS)

    int defaultLookback = intProp(message, "defaultLookbackMinutes", 15)
    int maxWindow       = intProp(message, "maxWindowMinutes", 60)

    // Last run high-water from the Data Store Get body (empty / unparseable => first run)
    String lastRunStr = (message.getBody(String) ?: "").trim()
    Instant lastRun = null
    if (!lastRunStr.isEmpty()) {
        try { lastRun = Instant.parse(lastRunStr) } catch (Exception ignored) {}
    }
    boolean firstRun = (lastRun == null)

    Instant windowFrom = firstRun ? now.minus(defaultLookback, ChronoUnit.MINUTES) : lastRun
    // Clock guard: never let the lower bound move past 'now'
    if (windowFrom.isAfter(now)) windowFrom = now

    // Gap cap (the OOM guard): pull at most maxWindow minutes per run
    boolean capped = false
    Instant windowTo
    if (Duration.between(windowFrom, now).toMinutes() > maxWindow) {
        windowTo = windowFrom.plus(maxWindow, ChronoUnit.MINUTES)
        capped = true
    } else {
        windowTo = now
    }

    message.setProperty("windowFrom",   windowFrom.toString())
    message.setProperty("runStartTime", windowTo.toString())      // upper bound AND next high-water
    message.setProperty("firstRun",     firstRun ? "true" : "false")
    message.setProperty("caughtUp",     capped ? "false" : "true")
    message.setProperty("truncated",    capped ? "true" : "false")

    // Response buffer + envelope metadata (defaults; override upstream if needed)
    message.setProperty("acc", "")
    message.setProperty("totalCount", 0)
    if (message.getProperty("tsField") == null)          message.setProperty("tsField", "ChangedOn")
    if (message.getProperty("splunkSourcetype") == null) message.setProperty("splunkSourcetype", "sap:s4hana:cloud:rolechanges")
    if (message.getProperty("splunkSource") == null)     message.setProperty("splunkSource", "sap:cpi:businessrolechangeslog")
    if (message.getProperty("s4System") == null)         message.setProperty("s4System", "s4hana-cloud")

    // Clear the (LastRun) body before the extraction loop
    message.setBody("")
    return message
}

int intProp(Message m, String name, int dflt) {
    def v = m.getProperty(name)
    if (v == null) return dflt
    try { return Integer.parseInt(v as String) } catch (Exception e) { return dflt }
}
