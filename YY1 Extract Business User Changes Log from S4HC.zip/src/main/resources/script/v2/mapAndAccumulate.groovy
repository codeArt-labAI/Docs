// This is Groovy Flowstep Version 2.x, running with Groovy runtime 4, Downgrade the script if older behaviour needed.

package script.v2

/*
 * mapAndAccumulate.groovy - YY1 Business User Changes
 * ---------------------------------------------------------------------------
 * Runs INSIDE the Looping Process Call's local process, once per page, AFTER the
 * XML-to-JSON converter. Each page's JSON is:
 *     { "BusinessUserChanges": { "BusinessUserChangesType": [ ...records... ] } }
 * (a single record may come as a Map instead of a 1-element List).
 *
 * Maps each record to Splunk-HEC NDJSON and APPENDS to property "acc", held as a
 * StringBuilder that persists across loop iterations (no O(n^2) string re-copies).
 * "Build Reply" returns ${property.acc} as the response body.
 *
 * Timestamp field: ChangedOn
 * NOTE: some S/4 logs emit the timestamp WITHOUT a timezone designator
 *       (e.g. "2026-02-16T13:31:08.000"). Instant.parse() rejects those, which
 *       would silently drop the HEC "time" field and make Splunk stamp ingest
 *       time instead of event time. toEpochSeconds() below handles all forms.
 *
 * MEMORY: this buffers the whole (already time-bounded) window in "acc". The real
 * out-of-memory guard is the window cap in resolveWindow.groovy (maxWindowMinutes).
 */
import com.sap.it.script.v2.api.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.io.Reader

Message processData(Message message) {
    def page
    Reader reader = message.getBody(java.io.Reader)
    if (reader != null) {
        try { page = new JsonSlurper().parse(reader) }
        catch (Exception e) { page = [:] }
        finally { try { reader.close() } catch (Exception ignored) {} }
    } else {
        page = [:]
    }

    // 1. Extract the record array. Primary: XML-to-JSON converter output shape.
    def records = []
    if (page instanceof Map && page.BusinessUserChanges instanceof Map) {
        def logType = page.BusinessUserChanges.BusinessUserChangesType
        if (logType instanceof List)      records = logType
        else if (logType instanceof Map)  records = [logType]   // single record
    }
    // 1b. Fallback: plain OData JSON { "value": [ ... ] } (if converter is bypassed)
    if (!records && page instanceof Map && page.value instanceof List) {
        records = page.value
    }
    // 1c. Fallback: OData V2 JSON { "d": { "results": [ ... ] } }
    if (!records && page instanceof Map && page.d instanceof Map && page.d.results instanceof List) {
        records = page.d.results
    }

    // Skip blank/empty pages so they don't disturb the buffer or counters.
    if (!records) { return message }

    // 2. Parameters (resolveWindow.groovy seeds these; defaults match this log type)
    def host       = (message.getProperty("s4System")         ?: "s4hana-cloud") as String
    def sourcetype = (message.getProperty("splunkSourcetype") ?: "sap:s4hana:cloud:userchanges") as String
    def source     = (message.getProperty("splunkSource")     ?: "sap:cpi:businessuserchangeslog") as String
    def tsField    = (message.getProperty("tsField")          ?: "ChangedOn") as String

    // 3. Persistent buffer across loop iterations
    StringBuilder sb
    def currentAcc = message.getProperty("acc")
    if (currentAcc instanceof StringBuilder)                        sb = currentAcc
    else if (currentAcc instanceof String && !currentAcc.isEmpty()) sb = new StringBuilder().append(currentAcc)
    else                                                            sb = new StringBuilder()

    // 4. Map records -> Splunk HEC NDJSON
    int mapped = 0
    int noTime = 0
    records.each { rec ->
        if (rec instanceof Map) {
            def env = [host: host, source: source, sourcetype: sourcetype, event: rec]
            Double epoch = toEpochSeconds(rec[tsField])
            if (epoch != null) env.time = epoch else noTime++
            sb.append(JsonOutput.toJson(env)).append("\n")
            mapped++
        }
    }

    // 5. Write the builder + running totals back to properties
    message.setProperty("acc", sb)
    message.setProperty("totalCount", asInt(message.getProperty("totalCount")) + mapped)
    if (noTime > 0) {
        // surfaced in MPL so a timestamp-format regression is visible, not silent
        message.setProperty("noTimeCount", asInt(message.getProperty("noTimeCount")) + noTime)
    }
    return message
}

/** Tolerant timestamp -> epoch seconds (fractional). Returns null if unparseable. */
Double toEpochSeconds(Object raw) {
    if (raw == null) return null
    String v = (raw as String).trim()
    if (v.isEmpty()) return null
    // "2026-08-12T02:31:17.451688Z" / "...+10:00"
    try { return Instant.parse(v).toEpochMilli() / 1000.0d } catch (Exception ignored) {}
    try { return OffsetDateTime.parse(v).toInstant().toEpochMilli() / 1000.0d } catch (Exception ignored) {}
    // "2026-02-16T13:31:08.000" (no zone) -> treat as UTC
    try { return LocalDateTime.parse(v).toInstant(ZoneOffset.UTC).toEpochMilli() / 1000.0d } catch (Exception ignored) {}
    // "/Date(1234567890000)/" (OData V2 JSON epoch form) - parsed without regex
    try {
        if (v.startsWith("/Date(")) {
            int end = v.indexOf(")")
            if (end > 6) {
                String num = v.substring(6, end)
                int sign = num.indexOf("+", 1)
                if (sign < 1) sign = num.indexOf("-", 1)
                if (sign > 0) num = num.substring(0, sign)
                return Long.parseLong(num) / 1000.0d
            }
        }
    } catch (Exception ignored) {}
    return null
}

int asInt(Object o) {
    if (o == null) return 0
    try { return o as Integer } catch (Exception ignored) { return 0 }
}
