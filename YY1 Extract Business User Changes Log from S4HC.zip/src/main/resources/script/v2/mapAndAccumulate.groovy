// This is Groovy Flowstep Version 2.x, running with Groovy runtime 4, Downgrade the script if older behaviour needed.

package script.v2

/*
 * mapAndAccumulate.groovy — YY1 
 * ---------------------------------------------------------------------------
 * Runs INSIDE the Looping Process Call's local process, once per page, AFTER the
 * XML-to-JSON converter. Each page's JSON is:
 *     { "BusinessUserChanges": { "BusinessUserChangesType": [ ...records... ] } }
 * (a single record may come as a Map instead of a 1-element List).
 *
 * It maps each record to Splunk-HEC NDJSON and APPENDS to property "acc", held as
 * a StringBuilder that persists across loop iterations (memory-friendly — no
 * O(n^2) string re-copies). "Build Reply" returns ${property.acc} as the body.
 *
 * NOTE on memory: this buffers the whole (already time-bounded) window in "acc".
 * The real out-of-memory guard is the window cap in resolveWindow.groovy
 * (maxWindowMinutes) — keep that sane for your event volume.
 */
import com.sap.it.script.v2.api.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant
import java.io.Reader

Message processData(Message message) {
    def page
    Reader reader = message.getBody(java.io.Reader)
    if (reader != null) {
        try { page = new JsonSlurper().parse(reader) }
        catch (Exception e) { page = [:] }
        finally { try { reader.close() } catch (Exception ignored) {} }
    } else {
        page = [:]
    }

    // 1. Extract the record array. Primary: converter output shape.
    def records = []
    if (page instanceof Map && page.BusinessUserChanges instanceof Map) {
        def logType = page.BusinessUserChanges.BusinessUserChangesType
        if (logType instanceof List)      records = logType
        else if (logType instanceof Map)  records = [logType]   // single record
    }
    // 1b. Fallback: plain OData JSON { "value": [ ... ] } (if converter is bypassed)
    if (!records && page instanceof Map && page.value instanceof List) {
        records = page.value
    }

    // Skip blank/empty pages so they don't disturb the buffer or counters.
    if (!records) { return message }

    // 2. Parameters
    def host       = (message.getProperty("s4System")         ?: "s4hana-cloud") as String
    def sourcetype = (message.getProperty("splunkSourcetype") ?: "sap:s4hana:cloud:userchanges") as String
    def source     = (message.getProperty("splunkSource")     ?: "sap:cpi:businessuserchangeslog") as String
    def tsField    = (message.getProperty("tsField")          ?: "log_tstmp") as String

    // 3. Persistent buffer across loop iterations
    StringBuilder sb
    def currentAcc = message.getProperty("acc")
    if (currentAcc instanceof StringBuilder)                       sb = currentAcc
    else if (currentAcc instanceof String && !currentAcc.isEmpty()) sb = new StringBuilder().append(currentAcc)
    else                                                           sb = new StringBuilder()

    // 4. Map records -> Splunk NDJSON
    records.each { rec ->
        if (rec instanceof Map) {
            def env = [host: host, source: source, sourcetype: sourcetype, event: rec]
            def tsVal = rec[tsField]
            if (tsVal != null) {
                try { env.time = Instant.parse(tsVal as String).toEpochMilli() / 1000.0 }
                catch (Exception ignored) {}
            }
            sb.append(JsonOutput.toJson(env)).append("\n")
        }
    }

    // 5. Write the builder + running total back to properties
    message.setProperty("acc", sb)
    int total = 0
    def currentTotal = message.getProperty("totalCount")
    if (currentTotal != null) { try { total = currentTotal as Integer } catch (Exception ignored) {} }
    message.setProperty("totalCount", total + records.size())

    return message
}
