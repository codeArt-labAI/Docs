# YY1 Extract Security Audit Log from S4HC

**Request–reply (pull) variant.** A consumer (Splunk modular input, a scheduler, or any
HTTP client) calls the CPI HTTPS endpoint; CPI reads the delta window, pulls the
**S/4HANA Cloud Security Audit Log** via **OData V4** (with full pagination), and
**returns the events in the HTTP response body** — as NDJSON. There is **no push to
Splunk HEC**; the reply *is* the delivery.

This is the sibling of `SecAuditLog_To_Splunk` (which POSTs to HEC and replies 200). Same
delta / high-water / pagination / lock / exception machinery — the difference is the tail:
aggregate the pages and reply with them instead of pushing.

---

## Endpoint contract

```
POST  https://<cpi-runtime-host>/http/extract/secauditlog
GET   https://<cpi-runtime-host>/http/extract/secauditlog          (GET works too)
```

**Optional request header**

| Header | Meaning |
|---|---|
| `since: <ISO-8601 UTC>` | Pull the window `(since, now]` and **do not** advance the stored high-water (stateless / caller-owned checkpoint — use it to safely re-pull a window whose reply you missed). Omit it for normal server-managed delta. |

**Response**

- **Body**: NDJSON, one Splunk-HEC envelope per line — `{"time","host","source","sourcetype","event":{…}}` — directly ingestible by Splunk HEC or parseable by any consumer. Empty body + `204` when the window had no events.
- **Headers**:

| Header | Meaning |
|---|---|
| `X-Total-Count` | number of events in the body |
| `X-Window-From` / `X-Window-To` | the delta window used (`gt From and le To`) |
| `X-Next-Since` | value to send as `since` on the next call (= `X-Window-To`, or the last delivered event's timestamp if truncated) |
| `X-Truncated` | `true` when the `extract.maxEvents` cap stopped pagination early |

- **`429`** with `{"status":"skipped",...}` if a run is already in progress (concurrency lock).
- **`500`** with a JSON error body if extraction failed — the high-water is **not** advanced, so the next call re-pulls the window.

---

## What you actually have to change

| Change | Where | Value |
|---|---|---|
| **S/4HANA OData base URL** | `parameters.prop` → `odata.address` | `https://<tenant>-api.s4hana.cloud.sap/sap/opu/odata4/sap/rsau_log_api/srvd_a2x/sap/rsau_log_api/0001` |
| **S/4 OAuth2 client creds** (secret) | Security Material → *OAuth2 Credentials* | alias `S4HC_SAL_OAUTH` |

That's it — no HEC URL, no HEC token (there is no push). Everything else has defaults.

## Deploy

1. **Import** [`YY1_Extract_Security_Audit_Log_from_S4HC.zip`](../YY1_Extract_Security_Audit_Log_from_S4HC.zip)
   into your package (`Design → Add → Integration Flow → Import`).
2. **Create security material**: *OAuth2 Credentials* `S4HC_SAL_OAUTH` (S/4HANA Cloud comm
   arrangement **SAP_COM_0750** client id/secret + token URL).
3. **Configure** and set `odata.address`. Confirm the OData channel opens as **V4**.
4. **Save → Deploy**; grab the endpoint ending in `/extract/secauditlog`.
5. Create/assign the sender role `Splunk_SecAudit_Trigger` and grant it to the caller's
   credentials/cert. CSRF is off for this POST.

## How the caller drives it

- **Simple (stateful):** just call the endpoint on your cadence (e.g. Splunk modular input
  every 15 min). CPI keeps the checkpoint and advances it after each successful reply.
- **Robust (stateless):** persist `X-Next-Since` from each response and send it as `since`
  on the next call. If a reply is lost, re-send with the previous `since` to re-pull — no
  data gap. Combine with dedup on a stable key (timestamp + user + terminal + message id).

## Design notes

- **Aggregation**: pages are accumulated into a buffer (`appendBuffer.groovy`) and returned
  together — a single reply must hold the whole window, so it is buffered in memory.
- **Response-size cap** (`extract.maxEvents`, default `0` = unlimited): bounds that buffer.
  When hit, pagination stops, `X-Truncated:true` is returned, and the high-water is set to
  the **last delivered event's timestamp** so the remainder is re-pulled next call
  (at-least-once preserved even when capped). Set this to your MPL memory budget.
- **High-water order**: written from a property (not the live body), so the reply body is
  free to carry the events.
- **At-least-once caveat**: because delivery is the HTTP reply, CPI cannot know the caller
  ingested it. Mitigate with the stateless `since` mode above and/or Splunk-side dedup.

## Scripts (`src/main/resources/script/`)

| Script | Role |
|---|---|
| `initRunWindow.groovy` | capture `runStartTime`; seed paging + **response buffer** |
| `evalLock.groovy` | lock Data-Store-Get → `lockHeld` |
| `resolveDelta.groovy` | lower bound + `advanceHighWater`; honors the `since` header |
| `buildODataQuery.groovy` | V4 query for the current page (unquoted literals, `$orderby asc`) |
| `pageAdvance.groovy` | `hasMore`, `$skip`, **maxEvents cap + last-ts tracking** |
| `toHecNdjson.groovy` | OData page → HEC NDJSON |
| `appendBuffer.groovy` | append the page to the response buffer |
| `buildReply.groovy` | emit the buffer as the HTTP reply + `X-*` headers |
| `handleError.groovy` | exception subprocess: MPL headers + JSON error reply |

---

## ⚠️ First-open verification (hand-authored `.iflw` is version-sensitive)

XML is well-formed and every reference resolves, but on first open the Web editor may prompt
to upgrade a few component versions — **accept** it, then re-verify:

1. **Looping Process Call** (`ProcessCall_Loop`) → points at the **Paginate** local process,
   loop condition `${property.hasMore} = 'true'`, max-iteration cap set to throw.
2. **Both routers** — `Lock held?` (`lockHeld='X'` → busy/429) and `Advance high-water?`
   (`advanceHighWater='false'` → skip the high-water write). Note `Release Lock` has **two**
   incoming flows (from the write path and the stateless skip) — a normal OR-join.
3. **Data Store** Get/Write/Delete operations, store `SEC_AUDIT_DELTA`, correct entry ids;
   *Get* → "Throw Exception on Missing Entry = false".
4. **Exception Subprocess** wired (Handle Error → Write Error Marker → Release Lock → End).
5. **OData channel** opens as **V4**, `Query(GET)`, resource path `SecurityAuditLog`,
   Query Options `${property.odataQuery}`. No Splunk receiver exists in this variant.

## Reuse for the other three log types

Change `odata.entitySet`, `odata.tsField`, `splunk.sourcetype`, and the Data Store entry
ids. Machinery is identical (SAP_COM_0894 RAL, SAP_COM_0933 user change, SAP_COM_0934 role
change).
