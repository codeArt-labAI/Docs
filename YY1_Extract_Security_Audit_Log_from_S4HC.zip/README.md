# YY1 Extract Security Audit Log from S4HC (persistent high-water)

**Request–reply (pull) flow.** A consumer calls the HTTPS endpoint; CPI resumes from the
**last-run timestamp** stored in a Data Store, pulls the **S/4HANA Cloud Security Audit Log**
via **OData V4** (native page-by-page pagination), and **returns the events in the HTTP
response** as Splunk-HEC NDJSON. Built entirely with the component descriptors exported
from your tenant, so it opens cleanly.

## Flow

```
HTTPS Start
  → Read Last Run  (Data Store Get, entry LastRun)
  → Resolve Window (Groovy: first-run bootstrap + gap cap)
  → Paginate       (Looping Process Call, while hasMoreRecords)
        local: Start → OData Request-Reply (one page) → XML→JSON → Map+Accumulate → End
  → Set LastRun Value  (body = runStartTime)
  → Save Last Run  (Data Store Write, entry LastRun)
  → Build Reply    (body = accumulated NDJSON + X-* headers)
  → End (reply)
```

## The high-water logic (answers to your three questions)

The delta window is `log_tstmp gt windowFrom and log_tstmp le runStartTime`. `runStartTime`
becomes the next stored high-water.

### 1. First run (nothing stored yet)
`Read Last Run` uses **`stopOnMissingEntry = false`**, so on the very first call it returns an
empty body instead of erroring. `resolveWindow.groovy` detects the empty/unparseable value
and **bootstraps** `windowFrom = now − defaultLookbackMinutes` (default **15 min**) — so the
first run pulls a small, safe window, not "everything since the dawn of time".

### 2. Long gap without pulling 5 hours at once (the OOM guard)
If the iFlow hasn't run for, say, 5 hours, `windowFrom` = the last run (5h ago). Pulling 5h in
one reply would buffer a huge payload and risk MPL out-of-memory. So `resolveWindow.groovy`
**caps the span**:

```
runStartTime = min(now, windowFrom + maxWindowMinutes)      // default maxWindowMinutes = 60
```

- Only up to **1 hour** of data is pulled and buffered per invocation.
- The high-water is advanced to that capped `runStartTime` and **saved**, so the next call
  continues from there.
- The response carries **`X-Caught-Up: false`** (and `X-Truncated: true`) whenever it was
  capped — the caller should **re-invoke immediately** until `X-Caught-Up: true`.
- A 5-hour backlog therefore drains in ~5 bounded calls, each ≤ 1h of data. No single call
  ever holds 5h in memory.

Tune it by setting exchange properties `defaultLookbackMinutes` / `maxWindowMinutes` (e.g. in
the *Resolve Window* step or a Content Modifier). Lower `maxWindowMinutes` if your event
volume per hour is very high.

### 3. Why not just a bigger buffer?
Your `mapAndAccumulate.groovy` edits already help memory a lot — streaming `Reader` parse and a
persistent `StringBuilder` in `acc` (no O(n²) string re-copies). But the reply model must hold
the whole window in memory to return it in one response, so the **window cap above is the real
OOM control**; the StringBuilder just makes the buffering it does do cheap. Both are in.

## High-water persistence details

- **Store**: Data Store `SEC_AUDIT_DELTA`, entry id `LastRun`, visibility *Integration Flow*
  (`local`) — persists across runs of this iFlow. (`get/1.7.1`, `put/1.7.1`.)
- **Read**: `delete = false` (we keep the value; the write overwrites it), `stopOnMissingEntry
  = false` (first-run safe).
- **Write order**: the high-water is written **before** Build Reply — `Set LastRun Value` puts
  `runStartTime` into the body, `Save Last Run` stores it, then `Build Reply` swaps the body to
  the accumulated NDJSON (held in property `acc`, so the store write doesn't disturb it).

### At-least-once caveat
High-water advances before the HTTP reply is confirmed delivered, so a lost reply means that
(bounded, ≤ `maxWindowMinutes`) window isn't re-pulled automatically. Mitigate with Splunk-side
dedup on the composite key `eventID + log_tstmp + slgmand + sid + counter`, or have the caller
re-request with a `since` header (the plumbing/headers are already exposed).

## Your Groovy edit — review

Good and kept. Confirmed:
- streaming `Reader` parse — memory-friendly;
- persistent `StringBuilder` in `acc` — avoids repeated full-string copies;
- early-exit on empty pages — no counter/buffer disturbance;
- parses the real converter output `SecurityAuditLog.SecurityAuditLogType`.

Added: a defensive fallback to plain OData `value[]` in case the XML→JSON converter is ever
bypassed, so an empty page can't silently drop records.

## Response headers

`X-Total-Count`, `X-Window-From`, `X-Window-To`, `X-Next-Since` (= new high-water),
`X-Caught-Up` (false ⇒ call again), `X-First-Run`, `Content-Type: application/x-ndjson`.

## Deploy

1. Import [`YY1_Extract_Security_Audit_Log_from_S4HC.zip`](../YY1_Extract_Security_Audit_Log_from_S4HC.zip)
   (bundles the tenant EDMX).
2. OData receiver: Basic auth alias **`S4HC_AUDIT_DEV`** — already your tenant's value.
3. Deploy; call the endpoint `…/http/extract/secauditlog`. The Data Store `SEC_AUDIT_DELTA`
   is created automatically on first write.

## Scripts

- `resolveWindow.groovy` — first-run bootstrap + gap cap + window/metadata properties.
- `mapAndAccumulate.groovy` — per-page OData→HEC NDJSON accumulation (your edited version + fallback).
