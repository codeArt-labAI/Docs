/*
 * mapAndAccumulate.groovy — YY1 (reply/pull, tenant-aligned)
 * ---------------------------------------------------------------------------
 * Runs INSIDE the Looping Process Call's local process, once per page.
 *
 * The OData V4 receiver has "Process in Pages" (pagination=true), so each loop
 * iteration's body is ONE page: { "value":[...] }. This script maps that page
 * to Splunk-HEC NDJSON and APPENDS it to property "acc", which persists across
 * loop iterations (same exchange). After the loop, Content Modifier "Build
 * Reply" returns ${property.acc} as the HTTP response body.
 *
 * Timestamp field is log_tstmp (Edm.DateTimeOffset); "time" is epoch seconds.
 * The Splunk-side dedup key is the OData composite key:
 *   eventID + log_tstmp + slgmand + sid + counter
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant

Message processData(Message message) {

    def raw = message.getBody(String) ?: '{"value":[]}'
    def page
    try { page = new JsonSlurper().parseText(raw) } catch (Exception e) { page = [value: []] }

    def host       = (message.getProperty("s4System")         ?: "s4hana-cloud") as String
    def sourcetype = (message.getProperty("splunkSourcetype") ?: "sap:s4hana:cloud:audit") as String
    def source     = (message.getProperty("splunkSource")     ?: "sap:cpi:secauditlog") as String
    def tsField    = (message.getProperty("tsField")          ?: "log_tstmp") as String

    def sb = new StringBuilder()
    (page.value ?: []).each { rec ->
        def env = [host: host, source: source, sourcetype: sourcetype, event: rec]
        def tsVal = rec[tsField]
        if (tsVal != null) {
            try { env.time = Instant.parse(tsVal as String).epochSecond } catch (Exception ignored) {}
        }
        sb.append(JsonOutput.toJson(env)).append("\n")
    }

    // Accumulate across pages, and keep a running count.
    def acc = (message.getProperty("acc") ?: "") as String
    message.setProperty("acc", acc + sb.toString())
    int total = (message.getProperty("totalCount") ?: 0) as Integer
    message.setProperty("totalCount", total + ((page.value ?: []).size()))
    return message
}
