/*
 * pageAdvance.groovy — YY1 (reply/pull variant)
 * ---------------------------------------------------------------------------
 * Loop control on the raw OData V4 response (BEFORE the HEC mapping).
 *
 * Adds, versus the push variant:
 *   - maxTsSeen  : timestamp of the last row (rows are $orderby asc, so this is
 *                  the max ts delivered so far).
 *   - maxEvents cap : if property maxEvents > 0 and the cumulative returned count
 *                     reaches it, stop paginating (hasMore=false), mark
 *                     truncated=true, and lower effectiveHighWater to maxTsSeen so
 *                     the UNRETURNED remainder is re-pulled on the next call
 *                     (preserves at-least-once even when the reply is capped).
 *
 * Output properties:
 *   returnedCount, hasRecords, hasMore, pageSkip(+pageSize), cumReturned,
 *   truncated, maxTsSeen, effectiveHighWater
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {

    String raw = message.getBody(String) ?: '{"value":[]}'
    def page
    try { page = new JsonSlurper().parseText(raw) } catch (Exception e) { page = [value: []] }

    int pageSize   = (message.getProperty("pageSize")   ?: 1000) as Integer
    int pageSkip   = (message.getProperty("pageSkip")   ?: 0) as Integer
    int cumReturned= (message.getProperty("cumReturned")?: 0) as Integer
    int maxEvents  = (message.getProperty("maxEvents")  ?: 0) as Integer
    String tsField = (message.getProperty("tsField") ?: "LogTimestamp") as String

    def rows = (page instanceof Map && page.value instanceof List) ? page.value : []
    int returnedCount = rows.size()
    cumReturned += returnedCount

    // Track the max timestamp actually delivered (asc order -> last row).
    if (returnedCount > 0) {
        def lastTs = rows[-1][tsField]
        if (lastTs != null) message.setProperty("maxTsSeen", lastTs as String)
    }

    boolean nextLink = (page instanceof Map) && (page["@odata.nextLink"] != null) &&
                       ((page["@odata.nextLink"] as String).trim().length() > 0)
    boolean hasMore = nextLink || (returnedCount == pageSize && returnedCount > 0)

    // Enforce the response-size cap.
    if (maxEvents > 0 && cumReturned >= maxEvents) {
        hasMore = false
        message.setProperty("truncated", "true")
        def maxTs = message.getProperty("maxTsSeen")
        if (maxTs != null) message.setProperty("effectiveHighWater", maxTs as String)
    }

    message.setProperty("returnedCount", returnedCount)
    message.setProperty("hasRecords", returnedCount > 0 ? "X" : "")
    message.setProperty("hasMore", hasMore ? "true" : "false")
    message.setProperty("pageSkip", pageSkip + pageSize)
    message.setProperty("cumReturned", cumReturned)
    return message
}
