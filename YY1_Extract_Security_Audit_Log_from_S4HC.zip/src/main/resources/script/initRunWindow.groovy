/*
 * initRunWindow.groovy  — YY1 (reply/pull variant)
 * ---------------------------------------------------------------------------
 * Set the run window, paging state, and the RESPONSE ACCUMULATOR.
 *
 * Contract:
 *   - runStartTime captured ONCE (UTC, second precision): query upper bound AND
 *     the default next high-water value.
 *   - eventBuffer / totalCount accumulate the events that are returned to the
 *     caller in the HTTP reply (this flow REPLIES with the data; it does not push).
 *
 * Output properties:
 *   runStartTime, effectiveHighWater(=runStartTime by default), pageSize,
 *   pageSkip=0, hasMore=true, cumReturned=0, truncated=false,
 *   eventBuffer='', totalCount=0, plus envelope metadata defaults.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant
import java.time.temporal.ChronoUnit

Message processData(Message message) {

    String runStartTime = Instant.now().truncatedTo(ChronoUnit.SECONDS).toString()
    message.setProperty("runStartTime", runStartTime)
    message.setProperty("effectiveHighWater", runStartTime)   // may be lowered if truncated

    def pageSizeProp = message.getProperty("pageSize")
    int pageSize = (pageSizeProp != null && (pageSizeProp as String).isInteger()) ? (pageSizeProp as String).toInteger() : 1000
    message.setProperty("pageSize", pageSize)
    message.setProperty("pageSkip", 0)
    message.setProperty("hasMore", "true")
    message.setProperty("cumReturned", 0)
    message.setProperty("truncated", "false")

    // Response accumulator (this flow returns the data as the HTTP reply).
    message.setProperty("eventBuffer", "")
    message.setProperty("totalCount", 0)

    if (message.getProperty("s4System") == null)        message.setProperty("s4System", "s4hana-cloud")
    if (message.getProperty("splunkSourcetype") == null) message.setProperty("splunkSourcetype", "sap:s4hana:cloud:audit")
    if (message.getProperty("tsField") == null)          message.setProperty("tsField", "LogTimestamp")
    if (message.getProperty("bootstrapMinutes") == null) message.setProperty("bootstrapMinutes", "15")

    message.setBody("")
    return message
}
