/*
 * evalLock.groovy — YY1
 * ---------------------------------------------------------------------------
 * Turn the lock Data-Store-Get result into property lockHeld ('X' if a run is
 * already in progress). Body is cleared afterwards.
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def body = message.getBody(String)
    boolean held = (body != null && body.trim().length() > 0)
    message.setProperty("lockHeld", held ? "X" : "")
    message.setBody("")
    return message
}
