/*
 * resolveDelta.groovy — YY1 (reply/pull variant)
 * ---------------------------------------------------------------------------
 * Determine the lower bound of the delta window and the checkpoint mode.
 *
 * Two modes:
 *   STATEFUL (default): use the stored high-water; advance it after extraction.
 *   STATELESS (recovery / caller-owned): if the request carries a "since" HTTP
 *     header, use it as the lower bound and DO NOT advance the stored high-water.
 *     This lets a caller safely RE-PULL a window whose reply it never received
 *     (at-least-once without server-side delivery acknowledgement).
 *
 * Input:
 *   - message body   = Data Store Get result on the high-water entry (may be empty)
 *   - property runStartTime, bootstrapMinutes
 *   - header  since  = optional ISO-8601 UTC lower-bound override
 *
 * Output properties:
 *   lastHighWater, firstRun, advanceHighWater ('true'/'false')
 */
import com.sap.gateway.ip.core.customdev.util.Message
import java.time.Instant
import java.time.temporal.ChronoUnit

Message processData(Message message) {

    String runStartTime = message.getProperty("runStartTime")
    String since = message.getHeader("since", String)

    if (since != null && since.trim().length() > 0) {
        // ---- Stateless / caller-owned checkpoint --------------------------
        message.setProperty("lastHighWater", since.trim())
        message.setProperty("firstRun", "")
        message.setProperty("advanceHighWater", "false")
        message.setBody("")
        return message
    }

    // ---- Stateful: server-managed high-water ------------------------------
    String stored = message.getBody(String)
    stored = (stored == null) ? "" : stored.trim()

    if (stored.isEmpty()) {
        int mins = 15
        try { mins = Integer.parseInt(message.getProperty("bootstrapMinutes") as String) } catch (ignored) {}
        String lower = Instant.parse(runStartTime).minus(mins, ChronoUnit.MINUTES)
                              .truncatedTo(ChronoUnit.SECONDS).toString()
        message.setProperty("lastHighWater", lower)
        message.setProperty("firstRun", "X")
    } else {
        message.setProperty("lastHighWater", stored)
        message.setProperty("firstRun", "")
    }
    message.setProperty("advanceHighWater", "true")
    message.setBody("")
    return message
}
