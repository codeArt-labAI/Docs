/*
 * handleError.groovy — YY1 Exception Subprocess
 * ---------------------------------------------------------------------------
 * Runs when any step in the main flow throws. Its job is clean ERROR REPORTING:
 * the high-water is already safe (the "Save Last Run" step is only on the success
 * path, so a failure never advances it → the window is re-pulled next run).
 *
 * It:
 *   - builds a compact JSON error body returned to the caller,
 *   - stamps window bounds + an MPL custom status for traceability,
 *   - sets HTTP 500 so the consumer treats the pull as failed (and retries).
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

Message processData(Message message) {

    def ex = message.getProperty("CamelExceptionCaught")
    String errMsg = (ex != null) ? (ex.getMessage() ?: ex.toString()) : "Unknown error"

    String windowFrom   = message.getProperty("windowFrom")   as String
    String runStartTime = message.getProperty("runStartTime") as String

    // MPL custom headers for traceability / alerting
    message.setHeader("SAP_Audit_windowFrom", windowFrom)
    message.setHeader("SAP_Audit_windowTo",   runStartTime)
    message.setHeader("SAP_MessageProcessingLogCustomStatus", "SECAUDIT_FAILED")

    def err = [
        iflow      : "YY1_Extract_Security_Audit_Log_from_S4HC",
        status     : "FAILED",
        error      : errMsg,
        window_from: windowFrom,
        window_to  : runStartTime,
        note       : "High-water NOT advanced; this window is re-pulled on the next run."
    ]
    message.setBody(JsonOutput.toJson(err))
    message.setHeader("Content-Type", "application/json")
    message.setHeader("CamelHttpResponseCode", "500")
    return message
}
