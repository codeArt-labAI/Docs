/*
 * handleError.groovy — YY1 (reply/pull variant)
 * ---------------------------------------------------------------------------
 * Exception subprocess. Stamps window bounds into MPL custom headers, builds a
 * JSON error body that is returned to the caller, and (via the following steps)
 * releases the lock WITHOUT advancing the high-water — so the next call re-pulls
 * the same window.
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

Message processData(Message message) {

    def ex = message.getProperty("CamelExceptionCaught")
    String errMsg = ex != null ? (ex.getMessage() ?: ex.toString()) : "Unknown error"

    String lastHighWater = message.getProperty("lastHighWater") as String
    String runStartTime  = message.getProperty("runStartTime")  as String
    def    pageSkip      = message.getProperty("pageSkip")

    message.setHeader("SAP_Audit_lastHighWater", lastHighWater)
    message.setHeader("SAP_Audit_runStartTime",  runStartTime)
    message.setHeader("SAP_Audit_pageSkip",      pageSkip as String)
    message.setHeader("SAP_MessageProcessingLogCustomStatus", "SECAUDIT_FAILED")

    def alert = [
        iflow       : "YY1_Extract_Security_Audit_Log_from_S4HC",
        status      : "FAILED",
        error       : errMsg,
        window_from : lastHighWater,
        window_to   : runStartTime,
        note        : "High-water NOT advanced; re-call (optionally with 'since') to re-pull this window."
    ]
    message.setProperty("errorMarker", JsonOutput.toJson(alert))
    message.setBody(JsonOutput.toJson(alert))
    message.setHeader("Content-Type", "application/json")
    message.setHeader("CamelHttpResponseCode", "500")
    return message
}
