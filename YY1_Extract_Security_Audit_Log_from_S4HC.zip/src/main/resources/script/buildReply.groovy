/*
 * buildReply.groovy — YY1 (reply/pull variant)
 * ---------------------------------------------------------------------------
 * Final step before the End event: turn the accumulated buffer into the HTTP
 * RESPONSE returned to the caller (this is the delivery — there is no push).
 *
 * Body:
 *   NDJSON, one HEC envelope per line (directly ingestible by Splunk HEC
 *   /services/collector/event, or parseable by any consumer). Empty when the
 *   window had no events.
 *
 * Response headers (context for the caller / stateless recovery):
 *   Content-Type   : application/x-ndjson
 *   X-Total-Count  : number of events in the body
 *   X-Window-From  : lower bound used (exclusive)
 *   X-Window-To    : upper bound used (inclusive) = runStartTime
 *   X-Next-Since   : value to pass as the "since" header on the next pull
 *                    (= runStartTime normally, or the last delivered event's
 *                    timestamp when the response was truncated by the cap)
 *   X-Truncated    : true when the maxEvents cap stopped pagination early
 *   CamelHttpResponseCode : 200 (204 when empty)
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    String buffer = (message.getProperty("eventBuffer") ?: "") as String
    int    total  = (message.getProperty("totalCount") ?: 0) as Integer
    String from   = (message.getProperty("lastHighWater") ?: "") as String
    String to     = (message.getProperty("runStartTime") ?: "") as String
    String next   = (message.getProperty("effectiveHighWater") ?: to) as String
    String trunc  = (message.getProperty("truncated") ?: "false") as String

    message.setBody(buffer)
    message.setHeader("Content-Type", "application/x-ndjson")
    message.setHeader("X-Total-Count", String.valueOf(total))
    message.setHeader("X-Window-From", from)
    message.setHeader("X-Window-To", to)
    message.setHeader("X-Next-Since", next)
    message.setHeader("X-Truncated", trunc)
    message.setHeader("CamelHttpResponseCode", total > 0 ? "200" : "204")
    return message
}
