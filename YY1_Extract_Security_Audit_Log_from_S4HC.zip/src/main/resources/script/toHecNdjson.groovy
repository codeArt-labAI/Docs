/*
 * toHecNdjson.groovy — YY1
 * ---------------------------------------------------------------------------
 * Transform one OData V4 page into Splunk HEC newline-delimited JSON (NDJSON),
 * one { "time","host","source","sourcetype","event" } envelope per record.
 * The result is appended to the response buffer by appendBuffer.groovy.
 *
 * "time" is derived from the audit timestamp (epoch seconds) when parseable.
 * Empty pages produce an empty body (no-op).
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant

Message processData(Message message) {

    def body       = message.getBody(String) ?: '{"value":[]}'
    def page       = new JsonSlurper().parseText(body)
    def host       = (message.getProperty("s4System")        ?: "s4hana-cloud") as String
    def sourcetype = (message.getProperty("splunkSourcetype") ?: "sap:s4hana:cloud:audit") as String
    def source     = (message.getProperty("splunkSource")    ?: "sap:cpi:secauditlog") as String
    def tsField    = (message.getProperty("tsField")         ?: "LogTimestamp") as String

    def sb = new StringBuilder()
    (page.value ?: []).each { rec ->
        def env = [host: host, source: source, sourcetype: sourcetype, event: rec]
        def tsVal = rec[tsField]
        if (tsVal != null) {
            try { env.time = Instant.parse(tsVal as String).epochSecond } catch (Exception ignored) {}
        }
        sb.append(JsonOutput.toJson(env)).append("\n")
    }
    message.setBody(sb.toString())
    return message
}
