/*
 * buildODataQuery.groovy — YY1
 * ---------------------------------------------------------------------------
 * Assemble the OData V4 query options for the CURRENT page. Runs at the top of
 * the pagination loop so $skip reflects the current page.
 *
 * Exact V4 syntax: UNQUOTED Edm.DateTimeOffset literals; mandatory $orderby asc.
 * Output: property + header "odataQuery".
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    String ts     = (message.getProperty("tsField")      ?: "LogTimestamp") as String
    String lo     = message.getProperty("lastHighWater") as String
    String hi     = message.getProperty("runStartTime")  as String
    int    top    = (message.getProperty("pageSize")     ?: 1000) as Integer
    int    skip   = (message.getProperty("pageSkip")     ?: 0) as Integer
    String select = (message.getProperty("odataSelect")  ?: "") as String

    StringBuilder q = new StringBuilder()
    q.append('$filter=').append(ts).append(' gt ').append(lo)
     .append(' and ').append(ts).append(' le ').append(hi)
    q.append('&$orderby=').append(ts).append(' asc')
    if (select?.trim()) q.append('&$select=').append(select.trim())
    q.append('&$top=').append(top)
    q.append('&$skip=').append(skip)

    String query = q.toString()
    message.setProperty("odataQuery", query)
    message.setHeader("odataQuery", query)
    return message
}
