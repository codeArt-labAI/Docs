/*
 * appendBuffer.groovy — YY1 (reply/pull variant)
 * ---------------------------------------------------------------------------
 * Accumulate the current page's HEC NDJSON into the response buffer that is
 * returned to the caller at the end of the run. Runs once per page, after the
 * HEC mapping. Clears the body afterwards so only the buffer holds the data
 * (kept as a property, not the live body, so Data Store writes stay clean).
 *
 * NOTE: this flow returns ALL matched events in a single HTTP reply, so the
 * whole delta is buffered in memory. The maxEvents cap (pageAdvance.groovy)
 * bounds that buffer; tune {{extract.maxEvents}} to your MPL memory budget.
 */
import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    String buf = (message.getProperty("eventBuffer") ?: "") as String
    String page = message.getBody(String) ?: ""
    buf += page

    int total = (message.getProperty("totalCount") ?: 0) as Integer
    total += (message.getProperty("returnedCount") ?: 0) as Integer

    message.setProperty("eventBuffer", buf)
    message.setProperty("totalCount", total)
    message.setBody("")
    return message
}
