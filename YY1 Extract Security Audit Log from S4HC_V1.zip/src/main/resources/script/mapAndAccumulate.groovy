/*
 * mapAndAccumulate.groovy — YY1 (reply/pull, tenant-aligned)
 * ---------------------------------------------------------------------------
 * Runs INSIDE the Looping Process Call's local process, once per page.
 *
 * The OData V4 receiver has "Process in Pages" (pagination=true), so each loop
 * iteration's body is ONE page: { "value":[...] }. This script maps that page
 * to Splunk-HEC NDJSON and APPENDS it to property "acc", which persists across
 * loop iterations (same exchange). After the loop, Content Modifier "Build
 * Reply" returns ${property.acc} as the HTTP response body.
 *
 * Timestamp field is log_tstmp (Edm.DateTimeOffset); "time" is epoch seconds.
 * The Splunk-side dedup key is the OData composite key:
 *   eventID + log_tstmp + slgmand + sid + counter
 */
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.Instant
import java.io.Reader

Message processData(Message message) {
    def page
    Reader reader = message.getBody(java.io.Reader)
    
    if (reader != null) {
        try { 
            page = new JsonSlurper().parse(reader) 
        } catch (Exception e) { 
            page = [:] 
        } finally {
            try { reader.close() } catch (Exception ignored) {}
        }
    } else {
        page = [:]
    }
    
    // 1. Extract array from nested JSON structure
    def records = []
    if (page instanceof Map && page.SecurityAuditLog instanceof Map) {
        def logType = page.SecurityAuditLog.SecurityAuditLogType
        if (logType instanceof List) {
            records = logType
        } else if (logType instanceof Map) {
            records = [logType] // Fallback for 1 record
        }
    }
    
    // Exit early if page has no records to prevent blank iterations from messing with buffers
    if (!records) {
        return message 
    }

    // 2. Fetch parameters
    def host       = (message.getProperty("s4System")         ?: "s4hana-cloud") as String
    def sourcetype = (message.getProperty("splunkSourcetype") ?: "sap:s4hana:cloud:audit") as String
    def source     = (message.getProperty("splunkSource")     ?: "sap:cpi:secauditlog") as String
    def tsField    = (message.getProperty("tsField")          ?: "log_tstmp") as String

    // 3. CRITICAL: Initialize or retrieve a true persistent buffer across loop steps
    StringBuilder sbContainer = null
    def currentAcc = message.getProperty("acc")

    if (currentAcc instanceof StringBuilder) {
        sbContainer = currentAcc
    } else if (currentAcc instanceof String && !currentAcc.isEmpty()) {
        sbContainer = new StringBuilder().append(currentAcc)
    } else {
        sbContainer = new StringBuilder()
    }

    // 4. Map records into Splunk NDJSON formatting
    records.each { rec ->
        if (rec instanceof Map) {
            def env = [host: host, source: source, sourcetype: sourcetype, event: rec]
            def tsVal = rec[tsField]
            if (tsVal != null) {
                try { 
                    env.time = Instant.parse(tsVal as String).toEpochMilli() / 1000.0 
                } catch (Exception ignored) {}
            }
            sbContainer.append(JsonOutput.toJson(env)).append("\n")
        }
    }

    // 5. Force write the updated builder reference directly back to properties
    message.setProperty("acc", sbContainer)

    // 6. Update running total metrics safely
    int total = 0
    def currentTotal = message.getProperty("totalCount")
    if (currentTotal != null) {
        try { total = currentTotal as Integer } catch(Exception ignored) {}
    }
    message.setProperty("totalCount", total + records.size())
    
    return message
}
