# YY1 Extract Security Audit Log from S4HC (tenant-aligned rebuild)

**Request–reply (pull) flow.** A consumer calls the CPI HTTPS endpoint; CPI pulls the
**S/4HANA Cloud Security Audit Log** via **OData V4** (native page-by-page pagination) and
**returns the events in the HTTP response** as Splunk-HEC NDJSON. No push to Splunk.

> This version was rebuilt using the **exact component descriptors exported from your
> tenant** (`YY1 Extract Security Audit Log from S4HC_orig`). The earlier hand-authored
> version imported but failed to open (`Error while loading the details of the integration
> flow`) because several descriptors didn't match your tenant's model version. Those are
> now transplanted 1:1, so it should open cleanly.

## What was corrected (why the old one wouldn't open)

| Component | Old (broke open) | Now (from your tenant) |
|---|---|---|
| Looping Process Call | `ProcessCallElement/1.1.2` + a fake message flow to the local process | `cname::LoopingProcess/version::1.3.0`, `subActivityType=LoopingProcess`, real `<standardLoopCharacteristics>`, linked only by `processId` (no message flow) |
| Local Integration Process | `IntegrationProcess` | `cname::LocalIntegrationProcess/version::1.1.3` + `processType=directCall` |
| Local start/end | `MessageStartEvent`/`MessageEndEvent` + event def | plain `StartEvent`/`EndEvent` (no version, no event def) |
| Content Modifier | `Enricher/1.5.0`, `bodyContent` | `Enricher/version::1.6.3`, `wrapContent` |
| OData V4 adapter | `HCIOData/1.10.0`, `resourcePath`, `Query(GET)` | `sap:HCIOData/version::1.23.0`, `resourcePathForOdatav4`, `operation=get`, `pagination=true` |

## Flow

```
HTTPS Start → Init Window → Paginate (Looping Process Call, while hasMoreRecords) → Build Reply → End(reply)
                                        └─ local: Start → OData Request-Reply (page) → Map+Accumulate → End
```

- **Init Window** (Content Modifier): sets `runStartTime = now (UTC)` and
  `windowFrom = now − 15m (UTC)` using `${date-with-timezone:...}`, plus envelope metadata.
  Initializes the `acc` buffer.
- **OData V4 Request-Reply**: `pagination=true`, so each loop iteration fetches one page and
  the adapter sets `${property.Receiver.OData.hasMoreRecords}`; the Looping Process Call
  repeats until it is not `true`. Query:
  `$filter=(log_tstmp gt ${windowFrom} and log_tstmp le ${runStartTime})&$orderby=log_tstmp asc`
  with the real `$select` field list. `log_tstmp` is the audit timestamp
  (`Edm.DateTimeOffset`, unquoted V4 literal).
- **Map + Accumulate** (`mapAndAccumulate.groovy`): maps each page's `value[]` to HEC NDJSON
  (`{time,host,source,sourcetype,event}`) and appends it to `acc` (persists across pages).
- **Build Reply** (Content Modifier): returns `${property.acc}` as the body with headers
  `X-Total-Count`, `X-Window-From`, `X-Window-To`, `X-Next-Since`, `Content-Type: application/x-ndjson`.

## Deploy

1. **Import** [`YY1_Extract_Security_Audit_Log_from_S4HC.zip`](../YY1_Extract_Security_Audit_Log_from_S4HC.zip).
   It bundles the tenant EDMX (`src/main/resources/edmx/…`) the OData channel references,
   so the adapter resolves offline.
2. The OData receiver uses **Basic auth** with credential alias **`S4HC_AUDIT_DEV`** (your
   tenant's existing alias) against `https://my435863.s4hana.cloud.sap/…/rsau_log_api/…/0001`.
   Change the address/alias in the OData channel if targeting a different system.
3. The HTTPS sender uses role **`ESBMessaging.send`** — tighten to a dedicated role for
   production.
4. **Save → Deploy**; call the endpoint ending in `/http/extract/secauditlog`.

## Design notes / what changed vs. the earlier design

To guarantee it opens, this rebuild **drops the components I had no verified descriptor for**
in your tenant and which caused (or risked) the model-load failure:

- **No Data Store high-water / no lock**: the window is stateless — `now−15m … now`, which is
  exactly right for a fixed 15-minute cadence. (A caller-supplied `since` header and a
  persisted checkpoint can be re-added.)
- **No Exception Subprocess yet**: failures surface as a normal message-processing error.

These are additive. If you want them back, the reliable way is the same one that just worked:
export a small iFlow from your tenant that contains a **Data Store Write/Get/Select** and an
**Exception Subprocess**, and I'll transplant those exact descriptors too. Native OData
pagination + the looping process call (the parts you care about) are already in and aligned.

## Splunk-side dedup

Composite key from the EDMX (use for dedup on re-pull / boundary overlap):
`eventID + log_tstmp + slgmand + sid + counter`.

## Script

`src/main/resources/script/mapAndAccumulate.groovy` — per-page OData→HEC NDJSON + accumulation.
