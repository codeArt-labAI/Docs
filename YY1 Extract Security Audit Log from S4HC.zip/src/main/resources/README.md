# YY1 Extract Security Audit Log from S4HC

Request-reply (pull) extraction: a consumer calls the HTTPS endpoint, CPI resumes from the
persisted last-run timestamp, pages through **SecurityAuditLog** via **OData V4**, and returns the events
in the HTTP response as Splunk-HEC NDJSON.

One of four sibling flows sharing an identical design (Security Audit, Read Access,
Business User Changes, Business Role Changes).

## Flow

```
HTTPS Start
  -> Read Last Run   (Data Store Get, SEC_AUDIT_DELTA / LastRun)
  -> Resolve Window  (first-run bootstrap + gap cap)
  -> Paginate        (Looping Process Call, while hasMoreRecords)
        local: Start -> OData V4 Request-Reply (one page) -> XML->JSON -> Map+Accumulate -> End
  -> Set LastRun Value -> Save Last Run (Data Store Write)
  -> Build Reply     (NDJSON body + X-* headers)
  -> End (reply)
  [Exception Subprocess: Error Start -> Handle Error -> Error End  => HTTP 500 + JSON]
```

## This flow's specifics

| Setting | Value |
|---|---|
| OData version | **OData V4** |
| Entity set | `SecurityAuditLog` |
| Timestamp field | `log_tstmp` |
| Timestamp format in payload | `2026-08-12T02:31:17.451688Z (has Z)` |
| `$filter` | `log_tstmp gt ${property.windowFrom} and log_tstmp le ${property.runStartTime}` |
| `$orderby` | `log_tstmp asc` |
| `$select` | 18 fields (all EDMX properties, validated) |
| Payload path (XML->JSON) | `SecurityAuditLog/SecurityAuditLogType` |
| Endpoint | `/extract/secauditlog` |
| Data Store / entry | `SEC_AUDIT_DELTA` / `LastRun` |
| Splunk sourcetype / source | `sap:s4hana:cloud:audit` / `sap:cpi:secauditlog` |
| Script flowstep versions | Groovy v2 (map/resolve), v1 (handleError) |

## Delta window logic

`log_tstmp gt windowFrom and log_tstmp le runStartTime`; `runStartTime` becomes the next high-water.

- **First run** (no stored `LastRun`): Data Store Get uses `stopOnMissingEntry=false`, and
  `resolveWindow.groovy` bootstraps `windowFrom = now - 15 min`.
- **Long gap (OOM guard)**: the window span is capped at `maxWindowMinutes` (60). If the flow
  has not run for hours, each invocation pulls at most one hour, saves the advanced high-water,
  and returns `X-Caught-Up: false` - call again until it is `true`. A 5-hour backlog drains in
  ~5 bounded calls instead of one giant, memory-blowing pull.
- Tune via exchange properties `defaultLookbackMinutes` / `maxWindowMinutes`.

## Response headers

`X-Total-Count`, `X-Window-From`, `X-Window-To`, `X-Next-Since`, `X-Caught-Up`, `X-First-Run`,
`Content-Type: application/x-ndjson`.

## Splunk-side dedup key

`eventID + log_tstmp + slgmand + sid + counter`

The high-water advances before the reply is confirmed delivered, so on a lost reply that
(bounded) window is not re-pulled automatically - dedup on the key above.

## Scripts

- `resolveWindow.groovy` - first-run bootstrap, gap cap, window + envelope properties
- `mapAndAccumulate.groovy` - per page: SecurityAuditLog/SecurityAuditLogType -> HEC NDJSON, accumulated in property `acc`
- `handleError.groovy` - exception subprocess: HTTP 500 + JSON error, MPL custom status

### Timestamp parsing
`mapAndAccumulate.groovy` parses `log_tstmp` tolerantly: `Instant` (trailing `Z`), then
`OffsetDateTime` (explicit offset), then `LocalDateTime` **treated as UTC** for values with no
timezone, plus the OData V2 `/Date(ms)/` form. Values that cannot be parsed leave `time` unset
(Splunk stamps ingest time) and increment the `noTimeCount` property so the regression is
visible in MPL rather than silent.
