# YY1 Extract Read Access Log from S4HC

Request-reply (pull) extraction: a consumer calls the HTTPS endpoint, CPI resumes from the
persisted last-run timestamp, pages through **ReadAccessLogRAW** via **OData V4**, and returns the events
in the HTTP response as Splunk-HEC NDJSON.

One of four sibling flows sharing an identical design (Security Audit, Read Access,
Business User Changes, Business Role Changes).

## Flow

```
HTTPS Start
  -> Read Last Run   (Data Store Get, READ_ACCESS_DELTA / LastRun)
  -> Resolve Window  (first-run bootstrap + gap cap)
  -> Paginate        (Looping Process Call, while hasMoreRecords)
        local: Start -> OData V4 Request-Reply (one page) -> XML->JSON -> Map+Accumulate -> End
  -> Set LastRun Value -> Save Last Run (Data Store Write)
  -> Build Reply     (NDJSON body + X-* headers)
  -> End (reply)
  [Exception Subprocess: Error Start -> Handle Error -> Error End  => HTTP 500 + JSON]
```

## This flow's specifics

| Setting | Value |
|---|---|
| OData version | **OData V4** |
| Entity set | `ReadAccessLogRAW` |
| Timestamp field | `LogTimestamp` |
| Timestamp format in payload | `2026-07-06T01:51:10Z (has Z)` |
| `$filter` | `LogTimestamp gt ${property.windowFrom} and LogTimestamp le ${property.runStartTime}` |
| `$orderby` | `LogTimestamp asc` |
| `$select` | 14 fields (all EDMX properties, validated) |
| Payload path (XML->JSON) | `ReadAccessLogRAW/ReadAccessLogRAWType` |
| Endpoint | `/extract/readaccesslog` |
| Data Store / entry | `READ_ACCESS_DELTA` / `LastRun` |
| Splunk sourcetype / source | `sap:s4hana:cloud:access` / `sap:cpi:readaccesslog` |
| Script flowstep versions | Groovy v2 (all three) |

## Delta window logic

`LogTimestamp gt windowFrom and LogTimestamp le runStartTime`; `runStartTime` becomes the next high-water.

- **First run** (no stored `LastRun`): Data Store Get uses `stopOnMissingEntry=false`, and
  `resolveWindow.groovy` bootstraps `windowFrom = now - 15 min`.
- **Long gap (OOM guard)**: the window span is capped at `maxWindowMinutes` (60). If the flow
  has not run for hours, each invocation pulls at most one hour, saves the advanced high-water,
  and returns `X-Caught-Up: false` - call again until it is `true`. A 5-hour backlog drains in
  ~5 bounded calls instead of one giant, memory-blowing pull.
- Tune via exchange properties `defaultLookbackMinutes` / `maxWindowMinutes`.

## Response headers

`X-Total-Count`, `X-Window-From`, `X-Window-To`, `X-Next-Since`, `X-Caught-Up`, `X-First-Run`,
`Content-Type: application/x-ndjson`.

## Splunk-side dedup key

`LogID (+ FieldName for row-level uniqueness)`

The high-water advances before the reply is confirmed delivered, so on a lost reply that
(bounded) window is not re-pulled automatically - dedup on the key above.

## Scripts

- `resolveWindow.groovy` - first-run bootstrap, gap cap, window + envelope properties
- `mapAndAccumulate.groovy` - per page: ReadAccessLogRAW/ReadAccessLogRAWType -> HEC NDJSON, accumulated in property `acc`
- `handleError.groovy` - exception subprocess: HTTP 500 + JSON error, MPL custom status

### Timestamp parsing
`mapAndAccumulate.groovy` parses `LogTimestamp` tolerantly: `Instant` (trailing `Z`), then
`OffsetDateTime` (explicit offset), then `LocalDateTime` **treated as UTC** for values with no
timezone, plus the OData V2 `/Date(ms)/` form. Values that cannot be parsed leave `time` unset
(Splunk stamps ingest time) and increment the `noTimeCount` property so the regression is
visible in MPL rather than silent.
